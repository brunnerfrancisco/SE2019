/*
 * timer.h
 *
 * Created: 15/09/2019 18:05:02
 *  Author: brunn
 */ 


#ifndef TIMER_H_
#define TIMER_H_

	void timer_init(void (* callback)(void));

#endif /* TIMER_H_ */